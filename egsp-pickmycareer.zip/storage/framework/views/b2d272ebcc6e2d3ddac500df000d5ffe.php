<div
    class="cf-turnstile"
    data-sitekey="<?php echo e(config('services.turnstile.key')); ?>"
    <?php if($attributes->has('wire:model')): ?>
        wire:ignore
        data-callback="captchaCallback"
        <?php echo e($attributes->filter(fn($value, $key) => ! in_array($key, ['data-callback', 'wire:model']))); ?>

    <?php else: ?>
        <?php echo e($attributes->whereStartsWith('data-')); ?>

    <?php endif; ?>
></div>

<?php if($attributes->has('wire:model')): ?>
    <script>
        function captchaCallback(token) {
            @this.set("<?php echo e($attributes->get('wire:model')); ?>", token);
        }
    </script>
<?php endif; ?>
<?php /**PATH F:\EGSP Projects\LMES\egsp-pickmycareer\vendor\ryangjchandler\laravel-cloudflare-turnstile\src\/../resources/views/components/turnstile.blade.php ENDPATH**/ ?>
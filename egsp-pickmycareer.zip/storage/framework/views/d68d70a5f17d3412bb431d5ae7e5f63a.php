<?php $__env->startSection('content'); ?>

<div class="ugf-bg">
    <div class="final-content">
      <div class="icon">
        <img src="<?php echo e(asset('/assets/images/big-green-check.png')); ?>" alt="">
      </div>
      <h2>Application Submitted</h2>
      <p>Thanks for your interest! <br> Our team will review your application and call you...</p>
    </div>
  </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\EGSP Projects\LMES\egsp-pickmycareer\resources\views/pages/submit.blade.php ENDPATH**/ ?>
@extends('layouts.app')
@section('content')

<div class="ugf-bg">
    <div class="final-content">
      <div class="icon">
        <img src="{{asset('/assets/images/big-green-check.png')}}" alt="">
      </div>
      <h2>Application Submitted</h2>
      <p>Thanks for your interest! <br> Our team will review your application and call you...</p>
    </div>
  </div>


@endsection
